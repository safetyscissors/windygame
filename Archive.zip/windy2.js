(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"windy2_atlas_1", frames: [[0,239,348,32],[508,233,192,88],[702,306,170,32],[350,234,122,32],[180,273,178,32],[0,273,178,60],[0,0,255,237],[257,0,249,232],[508,0,228,231],[738,0,125,304],[865,0,135,136],[865,138,87,120]]},
		{name:"windy2_atlas_2", frames: [[0,0,1500,1288],[1502,727,274,278],[1738,364,274,278],[1745,0,274,278],[1778,644,255,239],[1680,1007,195,376],[1825,1385,195,376],[1586,1668,237,372],[1502,0,241,362],[1502,364,234,361],[664,1290,357,361],[1023,1290,353,362],[991,1654,296,379],[664,1653,325,377],[1378,1290,300,376],[1289,1668,295,371],[0,1290,662,598]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_7 = function() {
	this.initialize(ss["windy2_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["windy2_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["windy2_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["windy2_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["windy2_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["windy2_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap27 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.camlevel11 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.camlevel12 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.camlevel13 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.camlevel21 = function() {
	this.initialize(ss["windy2_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.camlevel22 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.camlevel31 = function() {
	this.initialize(ss["windy2_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.camlevel32 = function() {
	this.initialize(ss["windy2_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.end = function() {
	this.initialize(ss["windy2_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.fro = function() {
	this.initialize(ss["windy2_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.hat = function() {
	this.initialize(ss["windy2_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.level01 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.level02 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.level11 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.level12 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.level13 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.level21 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.level22 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.level31 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.level32 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.level41 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.level42 = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Screenshot20240603at45657PM = function() {
	this.initialize(ss["windy2_atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.startTextSymbol = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Screenshot20240603at45657PM();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.startTextSymbol, new cjs.Rectangle(0,0,662,598), null);


(lib.selectGame = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_7();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.selectGame, new cjs.Rectangle(0,0,174,16), null);


(lib.reporterLines = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.reporterPlayCount = 0
		this.currentAudioIndex = -1;
		this.level = 0;
		this.lastLevel = 0;
		this.cooldown = 0;
		this.state;
		
		//setup
		console.log(1)
		this.finishSound = ()=> {
			console.log('dd')
			this.currentAudioIndex = -1;
		}
		this.windNoise = createjs.Sound.createInstance("windNoise"),
		this.windNoise.volume = .1;
		this.windNoise.play('windNoise', {loop:-1});
		this.sounds = [
			createjs.Sound.createInstance("line1a"),
			createjs.Sound.createInstance("line1d"),
			createjs.Sound.createInstance("line1f"),
			createjs.Sound.createInstance("line1g"),
			createjs.Sound.createInstance("line2a"),
			createjs.Sound.createInstance("line3a"),
			createjs.Sound.createInstance("line3d"),
			createjs.Sound.createInstance("line4f"),
		];
		this.sounds.forEach(sound=>{
			sound.on('complete', this.finishSound)
		})
		this.addEventListener('tick', audioTick.bind(this))
		
		function audioTick() {
			if (this.state != 'GAME') return;
			
			// if level changed, change audio
			if (this.lastLevel != this.level) {
				this.windNoise.volume = this.level/4 || .1;
				// decreasing intensity
				if (this.lastLevel > this.level) {
				// increasing intensity
				} else {
					console.log('increasing')
					this.sounds[this.currentAudioIndex].stop()
					this.finishSound()
				}
				this.lastLevel = this.level
				return;
			}
		
			// if not playing, then casually play next
			if (this.currentAudioIndex > -1) return
			
			// play once, for the first time.
			if (this.reporterPlayCount == 0) {
				this.currentAudioIndex = 0
				this.sounds[0].play()
				this.reporterPlayCount++;
			} else {
				// if nothing is playing, 
				if (this.level < 2) {
					this.currentAudioIndex = 1+((this.reporterPlayCount-1)%3)
					this.sounds[this.currentAudioIndex].play()
				}
				else if (this.level < 4) {
					this.currentAudioIndex = 4+((this.reporterPlayCount)%2)
					this.sounds[this.currentAudioIndex].play()
				}
				this.reporterPlayCount++;
			}
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text = new cjs.Text("reporter lines", "12px 'Times'", "#2E2C36");
	this.text.lineHeight = 14;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(-50,-13);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.reporterLines, new cjs.Rectangle(-52,-15,104,30), null);


(lib.levelupBannerBitmap = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("APNG1QAHingrihQgDgMADgLQAEgNAKACQAPAbAFAhIAChSQgQgEgWAHIglAPQgqARgYgNIgEAYQgWCKAkCGQgBAJgKACQgKACgGgHQgJgKADgYQAEgYgGgLQhOAyiAAFQg/ACgegUQgggVgMgvQgJghABg3IABkfQAAgMAHgKQAHgLAJAFQADC2gBChQAABeAvARQAMAFAZAAQA3AAAbgCQAtgDAjgJQApgLAQgXQAIgMADgSQABgMAAgWIgBjPQAAgbAOgDQAWAQACAjQABAMgCASICNg0QADhZArgVQATgKAlAEQAPACAIAFQANAJADAWQADAegUAaQgUAZgeAFIgUADQgLABgHAFQgNALAAAgIABFVQAAAQgFAHQgEAEgHABQgHAAgCgFgAP3hFQgEAFgBALQAAAMgCAFIgGALQgCAEABALQAAAJgDAEQAJABAPgEQASgGAGAAQAMgBAEgCQAFgCAGgGQAHgIADgEQAEgIgBgPQgBgSABgFIgyAAQgQAAgFAGgAxbE6IAArhQAAgQAKgCQAFAAAFAHQAGAJAAAVIAAK1QAAAagNAGgAAXDFQgEgPgCgbIgIh1QgFhJgHgjQgFgZgPgsQgQgvgFgVQgNg2AAgzQAAgPAIAAQAJgCACAQIASBZQAJAuAIAXQAOArAHAXQAHAYAEAfIAFA3IAMCqQACAbgEANQgOgMgHgWgAnpDfQgXgDgKgNQgHgHgFgYQgNg7gXg5QgTgzgEgOQgKgmAHgdIAQgDQAFAjAJAmQAKAmATA2QATA3ATAwQAWAIAYgKQAWgJAPgUQANgQAJgZQAFgPAIgfIA6jpQAFgQAIgBQAIAAACAJQADAIgDAKIgIAhIAMASQAtAEAUgJQALgEAMgKIAVgSQAbgWAggNQAUgIANADQAPAEAHAQQAHAQgFAPQgJAbgiARQgyAag5gIQgPBNABBUQAAARAGAGQAGAFAPAAQBxAEA7gJQATgDAFAIQAFAHgHAIQgGAHgKAEQgXAHgtgBIhhgCQggAAgOgLQgVgPABgxQAChJAMhIQgTADgMgBQgRgBgLgHQgHgFgEgGIglCRQgJAlgGARQgLAegOAVQgRAZgZAOQgWANgXAAIgIAAgAh4iSQg5AWgWAeIA3gCQALgBADgBIANgLQALgFAFgFQAIgIgDgXIgEgBQgIAAgMAFgAqXCLIgcgKQgNgEgYgCIglgEQgbgFgXgMQgOgHgGgKQgFgJABgYIAEhNQgRABgKgQQgBgHAHgGQAHgFAHAAIAQAAQAJAAAGgCQALgDALgQIAOgaIAPgaQAUgeAZgGQASATAHAZQAIAagDAZQgEAegTALQgJAFgYABIgkABQgPABgEACQgLAFgFANQgEALACAOIADAZQABAPgDAKQARAMAZAHQAPAEAfAFIBGAKQAKACAEgDQADgDACgFIABgKQABgFAEgDQAFgDADADQAOALgFAVQgEAUgRAFQgFACgGAAQgIAAgKgDgAr4hTQgLATgHAFIBCAAQgCgOACgbQAAgagNgMQgZAjgKAUg");
	this.shape.setTransform(-19.4995,0.5234);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF9900").s().p("EhFYALTIAA2lMCKxAAAIAAWlgALnBbQgEALAEAMQAqChgHCnQADAFAHAAQAHgBADgEQAGgHAAgQIgBlVQAAggAMgLQAHgFALgBIAUgDQAegFAUgZQAUgagDgeQgDgWgNgJQgHgFgQgCQglgEgTAKQgrAVgDBZIiNA0QACgSgBgMQgCgjgVgQQgPADAAAbIABDPQAAAWgBAMQgDASgIAMQgQAXgoALQgjAJguADQgbACg2AAQgaAAgMgFQgugRgBheQABihgDi2QgJgFgHALQgHAKABAMIgCEfQgBA3AJAhQAMAvAgAVQAfAUA/gCQB/gFBPgyQAFALgEAYQgDAYAJAKQAGAHAKgCQALgCAAgJQgkiGAXiKIADgYQAYANAqgRIAmgPQAVgHAQAEIgCBSQgEghgQgbIgDAAQgHAAgDALgA0Um0QgJACAAAQIAALhIAMAHQANgGAAgaIAAq1QAAgVgGgJQgEgHgFAAIgBAAgAj0lCQgHAAgBAPQAAAzANA2QAGAVAPAvQAPAsAFAZQAJAjAFBJIAIB1QACAbADAPQAHAWAOAMQAFgNgDgbIgMiqIgFg3QgEgfgHgYQgGgXgQgrQgIgXgIguIgShZQgDgOgHAAIgCAAgAsWhDQgIAdAKAmQAEAOATAzQAXA5ANA7QAGAYAGAHQAKANAXADQAbACAagPQAZgOARgZQAPgVAKgeQAGgRAJglIAmiRQADAGAHAFQAMAHARABQALABATgDQgMBIgBBJQgCAxAVAPQAPALAfAAIBiACQAsABAXgHQALgEAFgHQAHgIgFgHQgFgIgTADQg7AJhwgEQgPAAgHgFQgGgGAAgRQgBhUAPhNQA5AIAygaQAjgRAIgbQAFgPgGgQQgIgQgPgEQgNgDgTAIQghANgbAWIgUASQgNAKgLAEQgUAJgtgEIgLgSIAHghQADgKgDgIQgCgJgIAAQgIABgEAQIg7DpQgHAfgGAPQgJAZgMAQQgQAUgWAJQgYAKgWgIQgTgwgTg3QgTg2gJgnQgKglgFgjgAwKA5QgBAYAFAJQAGAKAOAHQAXAMAcAFIAlAEQAXACANAEIAcAKQARAFAMgEQARgFAFgUQAEgVgNgLQgEgDgEADQgFADgBAFIgBAKQgCAFgCADQgFADgKgCIhGgKQgfgFgPgEQgZgHgRgMQADgKgBgPIgDgZQgCgOAFgMQAEgMALgFQAEgCAPgBIAkgBQAYgBAJgFQAUgLADgeQADgZgIgaQgHgZgSgTQgZAGgUAeIgOAaIgPAaQgLAQgKADQgHACgJAAIgQAAQgHAAgHAFQgGAGAAAHQAKAQARgBgAMjAIQADgFAAgIQAAgLABgEIAHgLQABgFAAgMQABgLAEgFQAGgGAPAAIAyAAQgBAFABASQABAPgEAIQgDAEgHAIQgGAGgFACQgEACgMABQgGAAgSAFQgMAEgIAAIgEAAgAvNg2QAHgFALgTQALgUAYgjQAOAMAAAaQgDAbACAOgAk7iNQAQgGAIACQADAXgIAIQgEAFgMAFIgNALQgDABgLABIg3ACQAWgeA5gWg");
	this.shape_1.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.levelupBannerBitmap, new cjs.Rectangle(-444,-72.3,888.1,144.7), null);


(lib.hatSymbol = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.hat();
	this.instance.setTransform(-43.5,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.hatSymbol, new cjs.Rectangle(-43.5,-60,87,120), null);


(lib.hairInner = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.fro();
	this.instance.setTransform(-67.5,-68);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.hairInner, new cjs.Rectangle(-67.5,-68,135,136), null);


(lib.girlSymbol = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.level=0;
		var self = this;
		
		const levelIndex = [1, 14, 26, 34, 42];
		
		this.gotoLevel = function(n) {
			if (self.level == n) {
				self.gotoAndPlay(levelIndex[n]);
			}
			if (self.level < n) {
				self.gotoAndPlay(levelIndex[n-1]);
			}
		}
	}
	this.frame_12 = function() {
		this.gotoLevel(0)
	}
	this.frame_24 = function() {
		this.gotoLevel(1)
	}
	this.frame_32 = function() {
		this.gotoLevel(2)
	}
	this.frame_40 = function() {
		this.gotoLevel(3)
	}
	this.frame_48 = function() {
		this.gotoLevel(4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(12).call(this.frame_12).wait(12).call(this.frame_24).wait(8).call(this.frame_32).wait(8).call(this.frame_40).wait(8).call(this.frame_48).wait(1));

	// Layer_1
	this.instance = new lib.level01();
	this.instance.setTransform(-75,-168,0.928,0.928);

	this.instance_1 = new lib.level02();
	this.instance_1.setTransform(-69,-170,0.9349,0.9349);

	this.instance_2 = new lib.level12();
	this.instance_2.setTransform(-61,-159);

	this.instance_3 = new lib.level13();
	this.instance_3.setTransform(-64,-159);

	this.instance_4 = new lib.level11();
	this.instance_4.setTransform(-69,-162);

	this.instance_5 = new lib.level21();
	this.instance_5.setTransform(-138,-163);

	this.instance_6 = new lib.level22();
	this.instance_6.setTransform(-133,-161);

	this.instance_7 = new lib.level31();
	this.instance_7.setTransform(-79,-179);

	this.instance_8 = new lib.level32();
	this.instance_8.setTransform(-104,-178);

	this.instance_9 = new lib.level41();
	this.instance_9.setTransform(-111,-175);

	this.instance_10 = new lib.level42();
	this.instance_10.setTransform(-85,-173);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},6).to({state:[{t:this.instance_2}]},7).to({state:[{t:this.instance_3}]},4).to({state:[{t:this.instance_4}]},4).to({state:[{t:this.instance_5}]},4).to({state:[{t:this.instance_6}]},4).to({state:[{t:this.instance_7}]},4).to({state:[{t:this.instance_8}]},4).to({state:[{t:this.instance_9}]},4).to({state:[{t:this.instance_10}]},4).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-138,-179,359,389);


(lib.endGirlInner = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.end();
	this.instance.setTransform(-62.5,-152);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endGirlInner, new cjs.Rectangle(-62.5,-152,125,304), null);


(lib.effectiveScoreBar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(100));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgeAyIAAhjIA+AAIAABjg");
	this.shape.setTransform(-0.55,87.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgeA7IAAh1IA+AAIAAB1g");
	this.shape_1.setTransform(-0.55,86.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgeBEIAAiHIA+AAIAACHg");
	this.shape_2.setTransform(-0.55,86.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgeBNIAAiZIA+AAIAACZg");
	this.shape_3.setTransform(-0.55,85.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgeBWIAAirIA+AAIAACrg");
	this.shape_4.setTransform(-0.55,84.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgfBfIAAi9IA+AAIAAC9g");
	this.shape_5.setTransform(-0.5,83.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgfBoIAAjPIA+AAIAADPg");
	this.shape_6.setTransform(-0.5,82.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgfBxIAAjhIA+AAIAADhg");
	this.shape_7.setTransform(-0.5,81.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgfB6IAAjzIA+AAIAADzg");
	this.shape_8.setTransform(-0.5,80.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgfCDIAAkFIA+AAIAAEFg");
	this.shape_9.setTransform(-0.5,79.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgfCMIAAkXIA+AAIAAEXg");
	this.shape_10.setTransform(-0.5,78.975);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgfCVIAAkpIA+AAIAAEpg");
	this.shape_11.setTransform(-0.5,78.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgfCfIAAk8IA+AAIAAE8g");
	this.shape_12.setTransform(-0.5,77.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgfCnIAAlNIA+AAIAAFNg");
	this.shape_13.setTransform(-0.5,76.325);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgfCwIAAlfIA/AAIAAFfg");
	this.shape_14.setTransform(-0.45,75.425);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgfC5IAAlyIA/AAIAAFyg");
	this.shape_15.setTransform(-0.45,74.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgfDCIAAmEIA/AAIAAGEg");
	this.shape_16.setTransform(-0.45,73.65);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgfDLIAAmWIA/AAIAAGWg");
	this.shape_17.setTransform(-0.45,72.75);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgfDUIAAmnIA/AAIAAGng");
	this.shape_18.setTransform(-0.45,71.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgfDeIAAm6IA/AAIAAG6g");
	this.shape_19.setTransform(-0.45,71);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgfDnIAAnMIA/AAIAAHMg");
	this.shape_20.setTransform(-0.45,70.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgfDwIAAneIA/AAIAAHeg");
	this.shape_21.setTransform(-0.45,69.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgfD5IAAnxIA/AAIAAHxg");
	this.shape_22.setTransform(-0.45,68.325);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgeECIAAoDIA+AAIAAIDg");
	this.shape_23.setTransform(-0.4,67.45);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgeELIAAoVIA+AAIAAIVg");
	this.shape_24.setTransform(-0.4,66.55);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgeEUIAAonIA+AAIAAIng");
	this.shape_25.setTransform(-0.4,65.675);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgeEdIAAo5IA+AAIAAI5g");
	this.shape_26.setTransform(-0.4,64.775);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgeEmIAApLIA+AAIAAJLg");
	this.shape_27.setTransform(-0.4,63.875);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgeEuIAApbIA+AAIAAJbg");
	this.shape_28.setTransform(-0.4,63);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgeE4IAApvIA+AAIAAJvg");
	this.shape_29.setTransform(-0.4,62.125);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgeFBIAAqBIA+AAIAAKBg");
	this.shape_30.setTransform(-0.4,61.225);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgeFKIAAqTIA+AAIAAKTg");
	this.shape_31.setTransform(-0.4,60.325);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgfFTIAAqlIA+AAIAAKlg");
	this.shape_32.setTransform(-0.35,59.45);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgfFcIAAq3IA+AAIAAK3g");
	this.shape_33.setTransform(-0.35,58.575);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgfFlIAArJIA+AAIAALJg");
	this.shape_34.setTransform(-0.35,57.675);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgfFuIAArbIA+AAIAALbg");
	this.shape_35.setTransform(-0.35,56.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgfF3IAArtIA+AAIAALtg");
	this.shape_36.setTransform(-0.35,55.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgfGAIAAr/IA+AAIAAL/g");
	this.shape_37.setTransform(-0.35,55);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgfGJIAAsRIA+AAIAAMRg");
	this.shape_38.setTransform(-0.35,54.15);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgfGSIAAsjIA+AAIAAMjg");
	this.shape_39.setTransform(-0.35,53.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgfGbIAAs1IA+AAIAAM1g");
	this.shape_40.setTransform(-0.35,52.35);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgeGkIAAtHIA+AAIAANHg");
	this.shape_41.setTransform(-0.3,51.45);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgeGtIAAtZIA+AAIAANZg");
	this.shape_42.setTransform(-0.3,50.575);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgeG2IAAtrIA+AAIAANrg");
	this.shape_43.setTransform(-0.3,49.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgeG/IAAt9IA+AAIAAN9g");
	this.shape_44.setTransform(-0.3,48.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgeHIIAAuPIA+AAIAAOPg");
	this.shape_45.setTransform(-0.3,47.925);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgeHRIAAuhIA+AAIAAOhg");
	this.shape_46.setTransform(-0.3,47.025);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AgeHaIAAuzIA+AAIAAOzg");
	this.shape_47.setTransform(-0.3,46.125);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgeHjIAAvFIA+AAIAAPFg");
	this.shape_48.setTransform(-0.3,45.275);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgeHsIAAvXIA+AAIAAPXg");
	this.shape_49.setTransform(-0.3,44.375);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgfH1IAAvpIA+AAIAAPpg");
	this.shape_50.setTransform(-0.25,43.475);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgfH+IAAv7IA+AAIAAP7g");
	this.shape_51.setTransform(-0.25,42.575);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgfIHIAAwNIA+AAIAAQNg");
	this.shape_52.setTransform(-0.25,41.725);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgfIQIAAwfIA+AAIAAQfg");
	this.shape_53.setTransform(-0.25,40.825);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgfIZIAAwxIA+AAIAAQxg");
	this.shape_54.setTransform(-0.25,39.925);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgfIiIAAxDIA+AAIAARDg");
	this.shape_55.setTransform(-0.25,39.05);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AgfIrIAAxVIA+AAIAARVg");
	this.shape_56.setTransform(-0.25,38.15);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AgfI0IAAxnIA+AAIAARng");
	this.shape_57.setTransform(-0.25,37.275);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgfI+IAAx7IA+AAIAAR7g");
	this.shape_58.setTransform(-0.25,36.4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgeJHIAAyNIA+AAIAASNg");
	this.shape_59.setTransform(-0.2,35.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgeJQIAAyfIA+AAIAASfg");
	this.shape_60.setTransform(-0.2,34.6);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AgeJZIAAyxIA+AAIAASxg");
	this.shape_61.setTransform(-0.2,33.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AgeJhIAAzBIA+AAIAATBg");
	this.shape_62.setTransform(-0.2,32.85);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AgeJqIAAzTIA+AAIAATTg");
	this.shape_63.setTransform(-0.2,31.95);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgeJzIAAzlIA+AAIAATlg");
	this.shape_64.setTransform(-0.2,31.05);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AgeJ9IAAz5IA+AAIAAT5g");
	this.shape_65.setTransform(-0.2,30.175);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AgeKGIAA0LIA+AAIAAULg");
	this.shape_66.setTransform(-0.2,29.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AgeKPIAA0dIA+AAIAAUdg");
	this.shape_67.setTransform(-0.2,28.4);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AgfKYIAA0vIA+AAIAAUvg");
	this.shape_68.setTransform(-0.15,27.525);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AgfKhIAA1BIA+AAIAAVBg");
	this.shape_69.setTransform(-0.15,26.625);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AgfKqIAA1TIA+AAIAAVTg");
	this.shape_70.setTransform(-0.15,25.725);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgfKzIAA1lIA+AAIAAVlg");
	this.shape_71.setTransform(-0.15,24.85);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AgfK8IAA13IA+AAIAAV3g");
	this.shape_72.setTransform(-0.15,23.975);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AgfLFIAA2JIA+AAIAAWJg");
	this.shape_73.setTransform(-0.15,23.075);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AgfLOIAA2bIA+AAIAAWbg");
	this.shape_74.setTransform(-0.15,22.175);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AgfLXIAA2tIA+AAIAAWtg");
	this.shape_75.setTransform(-0.15,21.3);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AgfLgIAA2/IA+AAIAAW/g");
	this.shape_76.setTransform(-0.15,20.4);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AgeLpIAA3RIA+AAIAAXRg");
	this.shape_77.setTransform(-0.1,19.525);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AgeLyIAA3jIA+AAIAAXjg");
	this.shape_78.setTransform(-0.1,18.65);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgeL7IAA31IA+AAIAAX1g");
	this.shape_79.setTransform(-0.1,17.75);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgeMEIAA4HIA+AAIAAYHg");
	this.shape_80.setTransform(-0.1,16.85);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AgeMNIAA4ZIA+AAIAAYZg");
	this.shape_81.setTransform(-0.1,15.975);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AgeMWIAA4rIA+AAIAAYrg");
	this.shape_82.setTransform(-0.1,15.1);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AgeMfIAA49IA+AAIAAY9g");
	this.shape_83.setTransform(-0.1,14.2);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AgeMoIAA5PIA+AAIAAZPg");
	this.shape_84.setTransform(-0.1,13.3);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgeMxIAA5hIA+AAIAAZhg");
	this.shape_85.setTransform(-0.1,12.425);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgfM6IAA5zIA+AAIAAZzg");
	this.shape_86.setTransform(-0.05,11.525);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AgfNDIAA6FIA+AAIAAaFg");
	this.shape_87.setTransform(-0.05,10.65);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AgfNMIAA6XIA+AAIAAaXg");
	this.shape_88.setTransform(-0.05,9.775);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AgfNVIAA6pIA+AAIAAapg");
	this.shape_89.setTransform(-0.05,8.875);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgfNeIAA67IA+AAIAAa7g");
	this.shape_90.setTransform(-0.05,7.975);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AgfNnIAA7NIA+AAIAAbNg");
	this.shape_91.setTransform(-0.05,7.1);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AgfNwIAA7fIA+AAIAAbfg");
	this.shape_92.setTransform(-0.05,6.225);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AgfN5IAA7xIA+AAIAAbxg");
	this.shape_93.setTransform(-0.05,5.325);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AgfOCIAA8DIA+AAIAAcDg");
	this.shape_94.setTransform(-0.05,4.425);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AgfOMIAA8XIA/AAIAAcXg");
	this.shape_95.setTransform(0,3.55);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AgfOVIAA8pIA/AAIAAcpg");
	this.shape_96.setTransform(0,2.65);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AgfOdIAA85IA/AAIAAc5g");
	this.shape_97.setTransform(0,1.775);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AgfOmIAA9LIA/AAIAAdLg");
	this.shape_98.setTransform(0,0.9);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AgfOvIAA9dIA/AAIAAddg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-94.3,6.9,188.7);


(lib.debris = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2C36").s().p("AANA0QgKgEgIgQIgQAIQgLAFgGgFQgFgEABgLQAAgMgDgEIgHgJQgCgCAAgFQABgEAEgDIAMgFQAFgBAKgGQAJgEAGACQgBgJACgGQADgKAIAAQAHgBAEAIQACAFAAAJQgBAGACADQADAEAJAAQAUAAAEALQACAIgIAHQgEADgNAFQAAAEAEALQADAJgCAFQgCAHgIACIgGABQgEAAgEgCg");
	this.shape.setTransform(-0.01,-0.0156);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2E2C36").s().p("AgCArQgEgEgDgLIgrABQgJAAgEgCQgHgEACgJQABgIAJgDIAHgCIASgHQAIgEAAgFQAAgCgCgDIgFgEQgFgEgBgHQAAgGAEgEQAHgHALAEIARAIIAEABQADAAAEgDQALgHAHACQAHACACAJQABAEgBALIAWAMQAIAEADAEQACAEgBAFQgBAFgEADQgDACgIABIgXADIgEABQgCACAAAEQgBAIgDAEQgDAHgHACIgCAAQgHAAgFgHg");
	this.shape_1.setTransform(-0.3818,0.7006);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2E2C36").s().p("AgaA6QgDgEAAgLIAAgbQgFAAgEgEIgEgEIgHgDQgGgEgBgGQAAgIAHgEQAEgCAGAAIAKAAIALgfIADgIQAEgEAHAAQAFABAEAEQADAFACAGIALAbQAEABAJgCQAIgDAEACQAHABACAHQACAGgEAGQgCACgGAEQgGADgCADQAGAGAIAKQAEAFABAGQABAFgEAFQgEAFgGAAQgFABgJgGIgMgHIgNALQgHAHgHADIgFABQgHAAgEgFg");
	this.shape_2.setTransform(-1.0909,0.3175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2E2C36").s().p("AACA1IgJgTQgNAAgMADQgMAEgFgCQgFgBgDgGQgDgGACgFQACgEAIgGQANgJAIgCIgFgUIgDgHIgGgGQgDgDAAgHQAAgHADgEQADgFAHgBQAGAAAFAFIAEAGQAEAEAEACIATANQAIgFAEgFIAEgJQADgHAGgDQAHgEAHAEQAFAEABAIIgCAOIgGAWQAIAFACAFQAEAGgEAGQgFAHgOACQgEAMgBAHIgEANQgEAIgFABIgEABQgIAAgHgJg");
	this.shape_3.setTransform(-1.1752,1.0342);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},2).to({state:[{t:this.shape_2}]},2).to({state:[{t:this.shape_3}]},2).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.5,-5.9,14.3,13.2);


(lib.count5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2C36").s().p("AA2C2IgSgJIgRgIQgTgIgsgCQgtgBgTADQgQADgHgDQgGgBgDgGQgDgGACgFQAEgGANgBQA4gGAcABQAuABAiASIASAJQAMADAHgGQADgCAGgKQAMgdADgNQAFghgUgmQgLgTgNgFQgIgDgOABQgSABgjAKIhXAZQgTAFgGgIQgEgEAAgMIAAidQAAgQAIgEQACgEAEgBQAFgDAOAAQBmAHBqgWQAMgDAHACQAFABADAEQAEAEAAAEQgBAMgVAEQhyAUhugGIAAAEIAACQQA3gJAwgPQAZgIANgCQAWgDAQAIQAMAGAIAKQAHAIALAYQAOAhAAAVQAAATgHAWQgFAOgMAYQgGANgGAFQgHAGgLAAIgEABQgIAAgIgDg");
	this.shape.setTransform(0.0229,0.0111);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.count5, new cjs.Rectangle(-14.2,-18.4,28.5,36.9), null);


(lib.count4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2C36").s().p("AA7C1QgCgFAAgKIAAiZIAAAAIgTABIgVAFQgLACgVABIg3ADQgSABgTAAQgOABgGgGQgIgHADgNQACgGAFgOIAEgNQABgJACgFIAGgMIAGgMIADgPQADgGAHgIQACgEACgMQACgHAHgRQAGgOABgKIAEgQQAEgKAIABQAIABADAIQABAFgBAKQgEAUgOAiIgWA4QgOAigDAUQANABAWgCIAigDIAVAAQAMABAHgBIAggIIATgBIAAiTQAAgKACgEQAEgJAGAAQAJgBADAKQACAEAAALIAACSIAdAAQAJAAAEABQAIADABAGQABAIgJAEQgDACgNABIgbABIAACZQAAAKgCAFQgEAIgHAAQgIgBgDgHg");
	this.shape.setTransform(-0.0175,-0.0293);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.count4, new cjs.Rectangle(-13.4,-18.9,26.8,37.8), null);


(lib.count3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2C36").s().p("AgNCqQgOgCgSgEQgSgFghgNQgQgIgFgGQgEgGgFgNQgEgMgBgMIgBgVIgDgKQgBgFABgEQACgFAGgBQAHgCAFAEQAIAFACAPQAAAQABAIQABARANAMQAJAHAOAGQAKAEARADQAUAEAjAAQAWAAALgDQAJgCAMgHIAVgMQANgGAEgGQADgGABgNQAAgXgCgLQgDgLgFgLQgGgMgJgLQgJgKgKgIQgIgFgHgCIgOgCQg0gFgSAAQgMAAgFgCIgBAAQgIgCgBgGQgBgDACgDIAAgBQABgHAKgCQAHgBAIAAIAMAAQAUAAASgEQAXgEAFgNQAEgHgDgOQgFgVgRgQQgHgHgFgCQgIgDgKAAQgPAAgHABQgMABgIAFIgKAIQgHAGgEACQgHADgHgDQgIgCAAgHQAAgGAGgGIAOgJIAIgJQAEgFAEgDQAHgEATABQAdgBAOADQAVAFAQAUQAOASAGAZQAFAWgFAOQgEALgJAIIACAAQAHADAMAIQATAOALAOIAOAZIAJAWQAEALAAAQIgBAcQAAAPgCAFQgDAIgQAJQgWAOgTAJQghANglAAIgRAAg");
	this.shape.setTransform(0,-0.0119);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.count3, new cjs.Rectangle(-13.6,-17,27.299999999999997,34.1), null);


(lib.count2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2C36").s().p("AgmCjQgSAAgJgCQgTgDgPgLQgJgHgCgGQgBgGAEgLQALghAIgNQASggAfgTIAcgRQAHgEAMgNQAcgcAKgSQAEgGACgHQAFgVgSgSQgNgLgYgIQgMgDgHACQgGABgMAHIgLABQgHAAgEACQgFABgJAIQgIAHgFABQgHABgFgFQgGgGACgHQABgHALgJQAOgKAHgCIAKgCIAKgBIAUgFQAMgEAHAAQAOgBAZANQAeAQAIAPQAJANABAYQAAARgEAKQgEAKgPARQgoAugbARIgZAQQgPALgJAPQgGALgLAXQgEAHABAEQABAEAFACQAMAGAbAAIB8AAQASAAADAJQADAKgKAGQgGADgNAAg");
	this.shape.setTransform(0.0129,-0.0009);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.count2, new cjs.Rectangle(-11.1,-16.2,22.2,32.5), null);


(lib.count1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2C36").s().p("AiJCfQgDgLASgIQAUgJAJgCQALgCAWABIAzADQAGgLABgWQAGhKgEgsIgDgmQgBgXACgQIACgQQACgJgCgHQgMAHgNAMQgIAHgDACQgHAEgHgEQgDgCgBgFQgBgFACgFQACgFAKgIQAXgUARgLQAOgKAIAHQAEADABAMQABAegCAPIgDATQgCAMABAIIADAWQADARAAAYQAABAgDAZIgEAsIBeAHQAMABAFADQAEACACAEQADAFgCAEQgEAJgRgBQhigFg7AFIhNAFQgRgBgDgJg");
	this.shape.setTransform(-0.002,-0.007);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.count1, new cjs.Rectangle(-13.8,-16.9,27.700000000000003,33.8), null);


(lib.cameraman = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.level = 0;
		this.hasHat = true;
		this.hasHair = true;
		
		this.init = () => {
			this.level = 0;
			this.hasHat = true;
			this.hasHair = true;
			this.gotoAndStop(1);
		}
	}
	this.frame_10 = function() {
		if (this.level < 2) {
			this.gotoAndPlay(1);
		} else {
			if (this.hasHat) {
				this.dispatchEvent(new Event("lose-hat"));
				this.hasHat = false;
			}
		}
	}
	this.frame_18 = function() {
		if (this.level < 4) {
			this.gotoAndPlay(11);
		} else {
			if (this.hasHair) {
				this.dispatchEvent(new Event("lose-hair"));
				this.hasHair = false;
			}
		}
	}
	this.frame_27 = function() {
		this.gotoAndPlay(19);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(10).call(this.frame_10).wait(8).call(this.frame_18).wait(9).call(this.frame_27).wait(1));

	// Layer_1
	this.instance = new lib.camlevel11();
	this.instance.setTransform(-137,-139);

	this.instance_1 = new lib.camlevel12();
	this.instance_1.setTransform(-139,-125);

	this.instance_2 = new lib.camlevel13();
	this.instance_2.setTransform(-140,-118);

	this.instance_3 = new lib.camlevel21();
	this.instance_3.setTransform(-135,-131,1.1481,1.1481);

	this.instance_4 = new lib.camlevel22();
	this.instance_4.setTransform(-136,-132,1.1361,1.1361);

	this.instance_5 = new lib.camlevel31();
	this.instance_5.setTransform(-118,-109,1.0746,1.0746);

	this.instance_6 = new lib.camlevel32();
	this.instance_6.setTransform(-117,-108,1.0722,1.0722);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},3).to({state:[{t:this.instance_2}]},4).to({state:[{t:this.instance_3}]},4).to({state:[{t:this.instance_4}]},4).to({state:[{t:this.instance_5}]},4).to({state:[{t:this.instance_6}]},4).wait(5));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-140,-139,297.8,299);


(lib.timeout = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_124 = function() {
		this.gotoAndStop(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(124).call(this.frame_124).wait(1));

	// Layer_2
	this.instance = new lib.count4();
	this.instance.setTransform(34.2,-51.35);
	this.instance._off = true;

	this.instance_1 = new lib.count2();
	this.instance_1.setTransform(28.4,-52.05);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).wait(1).to({x:25.8524,y:-42.5193},0).wait(1).to({x:10.9897,y:-26.7965},0).wait(1).to({x:2.176,y:-17.4727},0).wait(1).to({x:0.1998,y:-15.3821},0).wait(1).to({x:-1.2227,y:-13.8773},0).wait(1).to({x:-2.2866,y:-12.7519},0).wait(1).to({x:-3.0943,y:-11.8974},0).wait(1).to({x:-3.7101,y:-11.246},0).wait(1).to({x:-4.1778,y:-10.7512},0).wait(1).to({x:-4.5292,y:-10.3794},0).wait(1).to({x:-4.7884,y:-10.1053},0).wait(1).to({x:-4.9742,y:-9.9088},0).wait(1).to({x:-5.1022,y:-9.7733},0).wait(1).to({x:-5.1857,y:-9.685},0).wait(1).to({x:-5.236,y:-9.6317},0).wait(1).to({x:-5.2637,y:-9.6025},0).wait(1).to({x:-5.2782,y:-9.5871},0).wait(1).to({x:-5.289,y:-9.5757},0).wait(1).to({x:-5.3052,y:-9.5585},0).wait(1).to({x:-5.3364,y:-9.5256},0).wait(1).to({x:-5.3926,y:-9.4662},0).wait(1).to({x:-5.4847,y:-9.3687},0).wait(1).to({x:-5.6254,y:-9.2199},0).wait(1).to({x:-5.8291,y:-9.0044},0).wait(1).to({x:-6.1136,y:-8.7034},0).wait(1).to({x:-6.5011,y:-8.2934},0).wait(1).to({x:-7.0208,y:-7.7437},0).wait(1).to({x:-7.7124,y:-7.0121},0).wait(1).to({x:-8.6341,y:-6.0371},0).wait(1).to({x:-9.8771,y:-4.7221},0).wait(1).to({x:-11.6023,y:-2.897},0).wait(1).to({x:-14.1626,y:-0.1885},0).wait(1).to({x:-24.202,y:10.4318},0).wait(1).to({x:-38.3841,y:25.4347},0).wait(1).to({x:-46.15,y:33.65},0).to({_off:true},13).wait(58));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(67).to({_off:false},0).wait(1).to({x:19.573,y:-42.4669},0).wait(1).to({x:4.912,y:-26.5501},0).wait(1).to({x:-1.4956,y:-19.5937},0).wait(1).to({x:-3.2578,y:-17.6805},0).wait(1).to({x:-4.5154,y:-16.3151},0).wait(1).to({x:-5.4391,y:-15.3123},0).wait(1).to({x:-6.125,y:-14.5677},0).wait(1).to({x:-6.6339,y:-14.0153},0).wait(1).to({x:-7.0074,y:-13.6097},0).wait(1).to({x:-7.2761,y:-13.318},0).wait(1).to({x:-7.4633,y:-13.1148},0).wait(1).to({x:-7.5876,y:-12.9798},0).wait(1).to({x:-7.6648,y:-12.896},0).wait(1).to({x:-7.7083,y:-12.8488},0).wait(1).to({x:-7.7302,y:-12.825},0).wait(1).to({x:-7.742,y:-12.8122},0).wait(1).to({x:-7.7547,y:-12.7984},0).wait(1).to({x:-7.7795,y:-12.7715},0).wait(1).to({x:-7.8282,y:-12.7187},0).wait(1).to({x:-7.9135,y:-12.626},0).wait(1).to({x:-8.0501,y:-12.4777},0).wait(1).to({x:-8.2554,y:-12.2549},0).wait(1).to({x:-8.5505,y:-11.9345},0).wait(1).to({x:-8.963,y:-11.4867},0).wait(1).to({x:-9.5299,y:-10.8712},0).wait(1).to({x:-10.3046,y:-10.0302},0).wait(1).to({x:-11.3696,y:-8.8739},0).wait(1).to({x:-12.8681,y:-7.247},0).wait(1).to({x:-15.0947,y:-4.8297},0).wait(1).to({x:-22.582,y:3.2989},0).wait(1).to({x:-37.0343,y:18.9892},0).wait(1).to({x:-45.15,y:27.8},0).to({_off:true},1).wait(25));

	// Layer_1
	this.instance_2 = new lib.count5();
	this.instance_2.setTransform(45.3,-54.05);
	this.instance_2._off = true;

	this.instance_3 = new lib.count3();
	this.instance_3.setTransform(33.55,-51.7);
	this.instance_3._off = true;

	this.instance_4 = new lib.count1();
	this.instance_4.setTransform(25.95,-51.55);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).wait(1).to({x:31.2531,y:-41.071},0).wait(1).to({x:11.1049,y:-22.4547},0).wait(1).to({x:5.7346,y:-17.4927},0).wait(1).to({x:3.551,y:-15.4752},0).wait(1).to({x:2.0343,y:-14.0738},0).wait(1).to({x:0.9577,y:-13.079},0).wait(1).to({x:0.1918,y:-12.3714},0).wait(1).to({x:-0.346,y:-11.8744},0).wait(1).to({x:-0.7135,y:-11.5349},0).wait(1).to({x:-0.9534,y:-11.3133},0).wait(1).to({x:-1.0993,y:-11.1784},0).wait(1).to({x:-1.1791,y:-11.1047},0).wait(1).to({x:-1.2169,y:-11.0697},0).wait(1).to({x:-1.235,y:-11.053},0).wait(1).to({x:-1.2546,y:-11.0349},0).wait(1).to({x:-1.2973,y:-10.9954},0).wait(1).to({x:-1.3862,y:-10.9134},0).wait(1).to({x:-1.5469,y:-10.7649},0).wait(1).to({x:-1.81,y:-10.5218},0).wait(1).to({x:-2.2134,y:-10.1491},0).wait(1).to({x:-2.8071,y:-9.6005},0).wait(1).to({x:-3.6612,y:-8.8113},0).wait(1).to({x:-4.882,y:-7.6833},0).wait(1).to({x:-6.649,y:-6.0507},0).wait(1).to({x:-9.3178,y:-3.5847},0).wait(1).to({x:-15.8505,y:2.4513},0).wait(1).to({x:-36.6205,y:21.6421},0).wait(1).to({x:-49.4,y:33.45},0).to({_off:true},15).wait(81));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(44).to({_off:false},0).wait(1).to({x:23.3488,y:-42.0689},0).wait(1).to({x:6.4055,y:-26.0724},0).wait(1).to({x:-0.9996,y:-19.0811},0).wait(1).to({x:-3.0362,y:-17.1583},0).wait(1).to({x:-4.4896,y:-15.7861},0).wait(1).to({x:-5.5571,y:-14.7783},0).wait(1).to({x:-6.3497,y:-14.03},0).wait(1).to({x:-6.9378,y:-13.4748},0).wait(1).to({x:-7.3695,y:-13.0672},0).wait(1).to({x:-7.68,y:-12.774},0).wait(1).to({x:-7.8963,y:-12.5698},0).wait(1).to({x:-8.0401,y:-12.4341},0).wait(1).to({x:-8.1292,y:-12.3499},0).wait(1).to({x:-8.1795,y:-12.3025},0).wait(1).to({x:-8.2048,y:-12.2785},0).wait(1).to({x:-8.2185,y:-12.2656},0).wait(1).to({x:-8.2332,y:-12.2518},0).wait(1).to({x:-8.2618,y:-12.2247},0).wait(1).to({x:-8.318,y:-12.1717},0).wait(1).to({x:-8.4166,y:-12.0786},0).wait(1).to({x:-8.5745,y:-11.9295},0).wait(1).to({x:-8.8117,y:-11.7055},0).wait(1).to({x:-9.1528,y:-11.3835},0).wait(1).to({x:-9.6295,y:-10.9335},0).wait(1).to({x:-10.2847,y:-10.3149},0).wait(1).to({x:-11.1799,y:-9.4697},0).wait(1).to({x:-12.4108,y:-8.3076},0).wait(1).to({x:-14.1426,y:-6.6726},0).wait(1).to({x:-16.7158,y:-4.2432},0).wait(1).to({x:-25.3686,y:3.9261},0).wait(1).to({x:-42.0709,y:19.695},0).wait(1).to({x:-51.45,y:28.55},0).to({_off:true},15).wait(34));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(91).to({_off:false},0).wait(1).to({x:17.5427,y:-42.6744},0).wait(1).to({x:3.2094,y:-27.5426},0).wait(1).to({x:-3.7706,y:-20.1737},0).wait(1).to({x:-5.5472,y:-18.2982},0).wait(1).to({x:-6.8217,y:-16.9527},0).wait(1).to({x:-7.764,y:-15.9579},0).wait(1).to({x:-8.4694,y:-15.2132},0).wait(1).to({x:-8.998,y:-14.6551},0).wait(1).to({x:-9.3911,y:-14.2402},0).wait(1).to({x:-9.6784,y:-13.9368},0).wait(1).to({x:-9.883,y:-13.7208},0).wait(1).to({x:-10.0231,y:-13.573},0).wait(1).to({x:-10.1136,y:-13.4774},0).wait(1).to({x:-10.1677,y:-13.4203},0).wait(1).to({x:-10.1967,y:-13.3897},0).wait(1).to({x:-10.2114,y:-13.3741},0).wait(1).to({x:-10.222,y:-13.363},0).wait(1).to({x:-10.2384,y:-13.3457},0).wait(1).to({x:-10.2711,y:-13.3111},0).wait(1).to({x:-10.3313,y:-13.2476},0).wait(1).to({x:-10.4311,y:-13.1422},0).wait(1).to({x:-10.5848,y:-12.98},0).wait(1).to({x:-10.8092,y:-12.7431},0).wait(1).to({x:-11.1252,y:-12.4095},0).wait(1).to({x:-11.56,y:-11.9504},0).wait(1).to({x:-12.1505,y:-11.327},0).wait(1).to({x:-12.9499,y:-10.4831},0).wait(1).to({x:-14.0412,y:-9.331},0).wait(1).to({x:-15.5687,y:-7.7185},0).wait(1).to({x:-17.833,y:-5.328},0).wait(1).to({x:-25.9187,y:3.2081},0).wait(1).to({x:-39.892,y:17.9598},0).wait(1).to({x:-47.65,y:26.15},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-65.1,-72.5,124.69999999999999,125.1);


(lib.startText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.startTextSymbol();
	this.instance.setTransform(331,-866.75,1,1,0,0,0,331,299);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:-382.6},0).wait(1).to({y:100.9},0).wait(1).to({y:182.8},0).wait(1).to({y:234.3},0).wait(1).to({y:268.1},0).wait(1).to({y:290.4},0).wait(1).to({y:304.75},0).wait(1).to({y:313.55},0).wait(1).to({y:318.5},0).wait(1).to({y:320.9},0).wait(1).to({y:321.85},0).wait(1).to({y:322.35},0).wait(1).to({y:323.4},0).wait(1).to({y:326.1},0).wait(1).to({y:331.5},0).wait(1).to({y:341.2},0).wait(1).to({y:357},0).wait(1).to({y:381.85},0).wait(1).to({y:420.2},0).wait(1).to({y:480.8},0).wait(1).to({y:585},0).wait(1).to({y:1111.15},0).wait(1).to({y:1552.6},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-1165.7,662,3017.3);


(lib.levelupBanner = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_24 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(24).call(this.frame_24).wait(1));

	// Layer_1
	this.instance = new lib.levelupBannerBitmap();
	this.instance.setTransform(-855.35,75.45,1,1,-4.9703);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:-532.0437,y:46.8536},0).wait(1).to({x:-175.6097,y:15.3271},0).wait(1).to({x:-114.6945,y:9.9392},0).wait(1).to({x:-77.3346,y:6.6347},0).wait(1).to({x:-52.4449,y:4.4332},0).wait(1).to({x:-35.7103,y:2.953},0).wait(1).to({x:-24.6327,y:1.9732},0).wait(1).to({x:-17.5823,y:1.3496},0).wait(1).to({x:-13.3959,y:0.9793},0).wait(1).to({x:-11.1784,y:0.7832},0).wait(1).to({x:-10.1918,y:0.6959},0).wait(1).to({x:-9.784,y:0.6598},0).wait(1).to({x:-9.338,y:0.6204},0).wait(1).to({x:-8.228,y:0.5222},0).wait(1).to({x:-5.7725,y:0.305},0).wait(1).to({x:-1.1757,y:-0.1015},0).wait(1).to({x:6.5597,y:-0.7857},0).wait(1).to({x:18.7811,y:-1.8667},0).wait(1).to({x:37.4687,y:-3.5196},0).wait(1).to({x:65.8611,y:-6.0309},0).wait(1).to({x:110.1438,y:-9.9477},0).wait(1).to({x:187.9176,y:-16.8268},0).wait(1).to({x:571.3081,y:-50.7376},0).wait(1).to({x:865.4,y:-76.75},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1303.9,-187.2,2617.9,373.2);


(lib.hat_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
		
		this.addEventListener("tick",fl_RotateContinuously_4.bind(this));
		
		function fl_RotateContinuously_4(){
			this.innerhat.rotation += 30
		}
		
		this.init = function() {
			this.gotoAndStop(1)
		}
	}
	this.frame_49 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(49).call(this.frame_49).wait(1));

	// Layer_1
	this.innerhat = new lib.hatSymbol();
	this.innerhat.name = "innerhat";
	this.innerhat._off = true;

	this.timeline.addTween(cjs.Tween.get(this.innerhat).wait(1).to({_off:false},0).to({x:-0.55,y:-73.7},3).to({x:32.25,y:-139.35},3).to({x:85.95,y:-192.1},3).to({x:145.25,y:-237.05},3).to({x:209.25,y:-274.15},3).to({x:273.95,y:-306},3).to({x:310.05,y:-354.8},3).to({x:236.65,y:-367.15},3).to({x:162.8,y:-355.4},3).to({x:105.35,y:-389.65},3).to({x:104.25,y:-461.75},3).to({x:126.85,y:-530.85},3).to({x:167.95,y:-593.05},3).to({x:222.6,y:-642.9},3).to({x:289.55,y:-670.7},3).to({x:361.7,y:-682.55},3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-44,-742.5,449.2,802.5);


(lib.hairSymbol = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
		
		this.addEventListener("tick",fl_RotateContinuously_4.bind(this));
		
		function fl_RotateContinuously_4(){
			this.hairInner.rotation += 30
		}
		
		this.init = function() {
			this.gotoAndStop(1)
		}
	}
	this.frame_40 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(40).call(this.frame_40).wait(1));

	// Layer_1
	this.hairInner = new lib.hairInner();
	this.hairInner.name = "hairInner";
	this.hairInner.setTransform(-50.35,135.95);
	this.hairInner._off = true;

	this.timeline.addTween(cjs.Tween.get(this.hairInner).wait(1).to({_off:false},0).to({x:8.5,y:101.95},3).to({guide:{path:[8.5,101.7,10.6,100.6,13,99.2,24,93.3,27.2,91.6,30.8,89.8,34.3,87.9,37.1,86.4,41.5,84.4,45.2,82.6,48.9,81.1,50.9,80.3,52.7,79.8,57.5,78.9,62.3,77.9,57,79.1,51.6,80.2,46.8,82.2,42,84.2,38.9,85.7,34.7,87.8,30.8,90,26.9,92.1,28.3,91.4,29.8,90.6,32.2,89.4,36.9,87,42.4,84.5,47.9,81.9,50.4,80.9,51.6,80.5,51.9,80.4,52.1,80.3,52.4,80.3,52.6,80.2,53.1,80.1,53.5,79.9,53.7,79.9,53.8,79.9,53.9,79.9,53.9,79.9,54,79.9,54,79.8,61.3,78.3,68.5,76.8]}},3).to({x:135.05,y:66.5},3).to({x:202.3,y:66.6},3).to({x:269.25,y:74.85},3).to({x:337,y:72.5},3).to({x:403,y:55.35},3).to({x:461.95,y:22.9},3).to({x:514.75,y:-19.6},3).to({x:580.25,y:-40},3).to({x:638.5,y:-74.7},3).to({x:698.7,y:-97.7},3).to({x:763.2,y:-76.05},3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-117.8,-165.7,948.5,369.7);


(lib.endGirlSymbol = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(9).call(this.frame_9).wait(1));

	// Layer_1
	this.instance = new lib.endGirlInner();

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:126.8,y:-80.2},9).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.5,-232.2,251.8,384.2);


// stage content:
(lib.windy2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {loading:0,menu:1,game:10,end:35};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,9,34,44];
	// timeline functions:
	this.frame_0 = function() {
		const LOAD_STATE = 'LOADING';
		const MENU_STATE = 'MENU';
		const GAME_STATE = 'GAME';
		const END_STATE = 'END';
		
		const SPAWN_FREQUENCY = (.25)/24;
		const TIMEOUT_MILLIS = 6 * 1000;
		
		// immutable
		const labels = this.labels;
		const root = this;
		
		// global vars
		let state = LOAD_STATE;
		let stateChanged = false;
		let input = -1;
		let effectiveScore = 0;
		let score = 0;
		let level = 0;
		let maxLevel = 0;
		let endTimeout = 0;
		
		// local vars
		let elements = [];
		let levelBanners = []
		this.stop();
		this.audioContext = new window.AudioContext();
		
		window.addEventListener("keydown", keyPressed.bind(this));
		this.addEventListener('tick', tick.bind(this))
		
		function keyPressed(evt) {
			const k = evt.key.toLowerCase();
			if (k == ' ' && state != GAME_STATE) {
				if (state == LOAD_STATE) {
					console.log('starting audio')
					root.audioContext.resume();
				}
				advanceGameState();
			} else if (k.match(/[0-9]/)) {
				input = Number(k);
			} else {
				console.log(k);
			}
		}
		
		this.gotoLabelAndPlay = function (labelName) {
		
			const label = this.labels.find((el) => el.label == labelName)
		
			if (!label) return false;
		
			this.gotoAndPlay(label.position)
		}
		
		function tick() {
			if (stateChanged) {
				if (state == MENU_STATE) {
					this.gotoLabelAndPlay('menu')
				}
				if (state == GAME_STATE) {
					startGame();
					this.gotoLabelAndPlay('game')
				}
				if (state == END_STATE) {
					this.gotoLabelAndPlay('end')
				}
				root.reporterLines.state = state
				stateChanged = false;
			}
		
			if (state == GAME_STATE) {
				gameTick();
			}
		
		}
		
		function gameTick() {
			// spawn in debris
			if (Math.random() < (SPAWN_FREQUENCY * level * level * level)) {
				const horizontal = Math.random() < .5 * (level / 4);
				let d = new lib.debris();
				d.x = horizontal ? 0 : Math.random() * lib.properties.width;
				d.y = horizontal ? Math.random() * lib.properties.height : 0;
				elements.push(d);
				root.addChild(d);
			}
			// despawn debris
			elements = elements.filter(e => {
				e.x += level * level * level;
				e.y += 4
				if (e.x > lib.properties.width) {
					root.removeChild(e);
					return false;
				}
				return true;
			});
		
			// spawn in level banners
			levelBanners = levelBanners.filter(b => {
				if (b.currentFrame >= 24) {
					root.removeChild(b);
					return false;
				}
				return true;
			})
		
			// if stopped, start endTimeout
			if (level == 0 && maxLevel > 0) {
				if (!endTimeout) {
					endTimeout = Date.now();
				}
			}
		
			// increment levels
			const THRESHOLDS = [5, 50, 100, 200, 100000];
			if (input > -1) {
				// when input is "0", drop a level
				if (input == 0 && level > 0) {
					effectiveScore = THRESHOLDS[level - 1] + 1;
				}
		
				effectiveScore += input
				score += input
				input = -1
				
				// max effective score
				if (effectiveScore >= 300) effectiveScore = 299;
				// increment level if over threshold
				let nextThreshold = THRESHOLDS[level] - effectiveScore;
				if (nextThreshold < input) {
					setLevel(level + 1);
				}
			}
		
			if (effectiveScore > 0) {
				root.effectiveScoreBar.gotoAndStop(effectiveScore / 3)
				effectiveScore--;
		
				let lastThreshold = effectiveScore - THRESHOLDS[level - 1];
		
				if (lastThreshold <= 0) {
					setLevel(level - 1);
				}
			}
		
			// end game timeout
			if (endTimeout) {
				// reset
				if (level > 0) {
					endTimeout = 0;
					root.countdownTimer.gotoAndStop(0);
					return;
				}
				// animate
				if ((Date.now() - endTimeout) > (TIMEOUT_MILLIS - 5700) && root.countdownTimer.currentFrame == 0) {
					root.countdownTimer.gotoAndPlay(2);
				}
				// end
				if ((Date.now() - endTimeout) > TIMEOUT_MILLIS) {
					endGame()
				}
			}
		}
		
		function startGame() {
			input = -1;
			effectiveScore = 0;
			score = 0;
			level = 0;
			maxLevel = 0;
			endTimeout = 0;
			
			elements = [];
			levelBanners = [];
		}
		
		function endGame() {
			// despawn debris
			elements.forEach(e => {
				root.removeChild(e);
			});
			elements = [];
			levelBanners.forEach(e => {
				root.removeChild(e);
			});
			levelBanners = [];
			root.cameraman.init();
			root.hatSymbol.init();
			root.hairSymbol.init();
		
			advanceGameState();
			root.scoreInput.text = "score: " + score;
		}
		
		function setLevel(n) {
			if (n > level && n > maxLevel) {
				maxLevel = n;
				const banner = new lib.levelupBanner();
				levelBanners.push(banner);
				banner.x = lib.properties.width / 2;
				banner.y = lib.properties.height / 2;
				root.addChild(banner);
			}
			level = n;
			root.girlSymbol.level = n;
			root.cameraman.level = n;
			root.reporterLines.level = n;
		}
		
		root.cameraman.addEventListener("lose-hat", () => { 
			root.hatSymbol.play()});
		
		root.cameraman.addEventListener("lose-hair", () => { 
			root.hairSymbol.play()});
		
		function advanceGameState() {
			stateChanged = true
			if (state == LOAD_STATE) {
				state = MENU_STATE
			}
			if (state == MENU_STATE) {
				state = GAME_STATE;
			} else if (state == GAME_STATE) {
				state = END_STATE;
			} else if (state == END_STATE) {
				state = MENU_STATE;
			}
		}
	}
	this.frame_9 = function() {
		this.stop();
	}
	this.frame_34 = function() {
		this.stop();
	}
	this.frame_44 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(25).call(this.frame_34).wait(10).call(this.frame_44).wait(1));

	// audio
	this.reporterLines = new lib.reporterLines();
	this.reporterLines.name = "reporterLines";
	this.reporterLines.setTransform(-42.25,-33.3);
	this.reporterLines._off = true;

	this.timeline.addTween(cjs.Tween.get(this.reporterLines).wait(34).to({_off:false},0).wait(11));

	// game
	this.hairSymbol = new lib.hairSymbol();
	this.hairSymbol.name = "hairSymbol";
	this.hairSymbol.setTransform(186.4,327.45);

	this.hatSymbol = new lib.hat_1();
	this.hatSymbol.name = "hatSymbol";
	this.hatSymbol.setTransform(95.6,444.05,1.1087,1.1087,44.9994);

	this.cameraman = new lib.cameraman();
	this.cameraman.name = "cameraman";
	this.cameraman.setTransform(151,461);

	this.girlSymbol = new lib.girlSymbol();
	this.girlSymbol.name = "girlSymbol";
	this.girlSymbol.setTransform(586.05,368.2,1.3277,1.3277);

	this.instance = new lib.endGirlSymbol();
	this.instance.setTransform(-70.5,529.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.girlSymbol},{t:this.cameraman},{t:this.hatSymbol},{t:this.hairSymbol}]},34).to({state:[{t:this.instance}]},1).wait(10));

	// labels
	this.instance_1 = new lib.CachedBmp_1();
	this.instance_1.setTransform(140.05,74.05,0.5,0.5);

	this.movieClip_1 = new lib.selectGame();
	this.movieClip_1.name = "movieClip_1";
	this.movieClip_1.setTransform(237,104.05,1,1,0,0,0,87,8);

	this.instance_2 = new lib.CachedBmp_10();
	this.instance_2.setTransform(184,200.05,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_9();
	this.instance_3.setTransform(166,156.05,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_8();
	this.instance_4.setTransform(140.05,74.05,0.5,0.5);

	this.instance_5 = new lib.startText();
	this.instance_5.setTransform(410.7,292.7,0.3378,0.3378,0,0,0,331.3,299);

	this.effectiveScoreBar = new lib.effectiveScoreBar();
	this.effectiveScoreBar.name = "effectiveScoreBar";
	this.effectiveScoreBar.setTransform(133.3,34.05,1,1,90);

	this.countdownTimer = new lib.timeout();
	this.countdownTimer.name = "countdownTimer";
	this.countdownTimer.setTransform(29.75,31.8);

	this.scoreInput = new cjs.Text("score", "12px 'Times'");
	this.scoreInput.name = "scoreInput";
	this.scoreInput.lineHeight = 14;
	this.scoreInput.parent = this;
	this.scoreInput.setTransform(213.55,127.05);

	this.instance_6 = new lib.CachedBmp_6();
	this.instance_6.setTransform(170,152.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.movieClip_1}]},1).to({state:[{t:this.instance_5}]},9).to({state:[{t:this.countdownTimer},{t:this.effectiveScoreBar}]},24).to({state:[{t:this.instance_6},{t:this.scoreInput}]},1).wait(10));

	// bg
	this.instance_7 = new lib.Bitmap27();
	this.instance_7.setTransform(-207,-137);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(34).to({_off:false},0).to({_off:true},1).wait(10));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(193,97.9,1100,1053.1);
// library properties:
lib.properties = {
	id: 'C2F809F9D42D43FE974E06079EAD77FD',
	width: 800,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/windy2_atlas_1.png?1717935233663", id:"windy2_atlas_1"},
		{src:"images/windy2_atlas_2.png?1717935233663", id:"windy2_atlas_2"},
		{src:"sounds/windNoise.mp3?1717935233708", id:"windNoise"},
		{src:"sounds/line1a.mp3?1717935233708", id:"line1a"},
		{src:"sounds/line1d.mp3?1717935233708", id:"line1d"},
		{src:"sounds/line1f.mp3?1717935233708", id:"line1f"},
		{src:"sounds/line1g.mp3?1717935233708", id:"line1g"},
		{src:"sounds/line2a.mp3?1717935233708", id:"line2a"},
		{src:"sounds/line3a.mp3?1717935233708", id:"line3a"},
		{src:"sounds/line3d.mp3?1717935233708", id:"line3d"},
		{src:"sounds/line4f.mp3?1717935233708", id:"line4f"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C2F809F9D42D43FE974E06079EAD77FD'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;